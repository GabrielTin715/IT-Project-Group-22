**HOW TO USE THIS APPICATION**

*Financial Calendar:*

1. Click on the date on the calendar to add an income/expense(input positive number of income, negative number for expenses)
2. Use the panel right side to choose the category of the income/expense
3. If you want to delete an income/expense, toggle "delete mode" and click on the event directly("delete mode" can be toggled using the button below the right panel)

*Debt Calculator:*

1. Use the right panel to add a debt
2. If you want to delete a debt: Choose the debt using the drop down menu in the right panel and click the "Delete" button
3. Use the drop down menu left side to switch between the "Add/Delete panel" and the "Snowball calculator"
4. If you want to add the debt to the calendar: click the "Drop debt plan onto calendar" button (caution: the inputted value shown on this module will disappear after that)

*Budget Planner:*

1. Click the "Enter your spending budget" button to add a new budget plan
2. Use the drop down menu to choose the category for the plan
3. Budget planned and budget left will be calculate automatically
4. Use the "reset budget" button to reset the budget plan into 0

*Chart:*

1. We got two charts: pie chart(showing expenses for each month) and line chart(showing balance for each month through out whole year)
2. Normally, the chart will be shown automatically after adding anything into the calendar
3. In case that any problem occurs, refresh the website
4. The "Pie chart refresh" button refresh the pie chart, which also can help with problem solving
5. Use the drop down menu to switch between the pie chart and line chart

*Resetting all data:*

1. The 'Reset All Data" button is located the bottom of the website, which you can find it by scrolling down at the "*Chart*" page
2. This button resets everything

