// Save a transaction record
// Each transaction includes an ID/category/amount/date

function saveTransaction(transactionCategory, transactionAmount, transactionDate) {
    let transactionsString = localStorage.getItem('transactions') || ''; // Get existing transactions
    let transactionId = Date.now(); // Generate unique ID based on timestamp
    let transactionEntry = transactionId + ':' + transactionCategory + ':' + transactionAmount + ':' + transactionDate; // Format transaction string

    if (transactionsString) {
        transactionsString += '|' + transactionEntry; // Append new transaction
    } else {
        transactionsString = transactionEntry; // Initialize if empty
    }
    localStorage.setItem('transactions', transactionsString); // Save back to storage
}

// Retrieve all stored transactions

function getAllTransactions() {
    let transactionsString = localStorage.getItem('transactions') || ''; // Get stored transactions
    return transactionsString.split('|').filter(item => item.trim() !== '').map(transactionEntry => {
        let parts = transactionEntry.split(':');
        return {
            id: parts[0],
            category: parts[1],
            amount: parts[2],
            date: parts[3]
        }; // Convert to structured object
    });
}

// Save a budget setting
function saveBudget(budgetCategory, budgetAmount) {
    let budgetsString = localStorage.getItem('budgets') || ''; // Retrieve budgets
    let budgetsArray = budgetsString.split('|').filter(item => item.trim() !== ''); // Convert to array

    let categoryFound = false;
    budgetsArray = budgetsArray.map(budgetEntry => {
        let parts = budgetEntry.split(':'); // Split category and amount
        if (parts[0] === budgetCategory) {
            categoryFound = true; 
            return budgetCategory + ':' + budgetAmount; // Update budget amount
        }
        return budgetEntry; // Keep unchanged
    });
    if (!categoryFound) {
        budgetsArray.push(budgetCategory + ':' + budgetAmount); // Add new category if not found
    }
    localStorage.setItem('budgets', budgetsArray.join('|')); // Save updated budgets
}


// Retrieve all stored budgets
function getAllBudgets() {
    let budgetsString = localStorage.getItem('budgets') || ''; // Get stored budgets
    return budgetsString.split('|').filter(item => item.trim() !== '').map(budgetEntry => { // Convert to array
        let parts = budgetEntry.split(':');
        return {
            category: parts[0],
            amount: parts[1]
        }; // Convert to object
    });
}

// Delete a transaction by ID

function deleteTransaction(transactionId) {
    let transactionsString = localStorage.getItem('transactions') || '';
    let transactionsArray = transactionsString.split('|').filter(item => item.trim() !== '');

    transactionsArray = transactionsArray.filter(transactionEntry => {
        let parts = transactionEntry.split(':');
        return parts[0] !== String(transactionId); // Remove matching ID
    });
    localStorage.setItem('transactions', transactionsArray.join('|')); 
}

// Clear all stored data

function clearAllData() {
    localStorage.removeItem('transactions');
    localStorage.removeItem('budgets');
    location.reload()
}