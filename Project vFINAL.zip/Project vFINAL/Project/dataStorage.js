// *Arrow functions*: accountsArray.map(accountEntry *=>* { *function equals to* accountsArray.map(function(accountEntry) {
// ||: if leftside is falsy (null, undefined, empty string), use right side value
// filter: Remove empty strings or blank content. *accountsArray.filter(item => item.trim() !== '')*
// split: Split a string into arrays according to a certain symbol. *'accountName:accountBalance'.split(':') = ['accountName', 'accountBalance']*
// join: Concatenate arrays into a string using specified symbols. *['accountName:accountBalance'].join('|') = 'accountName:accountBalance'*


function saveAccount(accountName, accountBalance) {
    let accountsString = localStorage.getItem('accounts') || ''; // Get stored accounts string or initialize empty
    let accountsArray = accountsString.split('|').filter(item => item.trim() !== ''); // Convert string to array and remove empty entries
    let accountFound = false;
    accountsArray = accountsArray.map(accountEntry => {
        let parts = accountEntry.split(':'); // Split each account into name and balance
        if (parts[0] === accountName) {
            accountFound = true;
            return accountName + ':' + accountBalance;
        }
        return accountEntry; // Keep unchanged if not matching
    });
    if (!accountFound) {
        accountsArray.push(accountName + ':' + accountBalance); 
    }

    localStorage.setItem('accounts', accountsArray.join('|')); // Save updated accounts back to **localStorage**
}


 // Retrieve all stored accounts
 // Returns Array of objects, each with 'name' and 'balance'

function getAllAccounts() {
    let accountsString = localStorage.getItem('accounts') || ''; // Retrieve stored accounts string
    return accountsString.split('|').filter(item => item.trim() !== '').map(accountEntry => {
        let parts = accountEntry.split(':'); // Split into name and balance
        return { name: parts[0], balance: parts[1] }; // Convert to object format
    });
}


// Save a transaction record
// Each transaction includes an ID/category/amount/date

function saveTransaction(transactionCategory, transactionAmount, transactionDate) {
    let transactionsString = localStorage.getItem('transactions') || ''; // Get existing transactions
    let transactionId = Date.now(); // Generate unique ID based on timestamp
    let transactionEntry = transactionId + ':' + transactionCategory + ':' + transactionAmount + ':' + transactionDate; // Format transaction string

    if (transactionsString) {
        transactionsString += '|' + transactionEntry; // Append new transaction
    } else {
        transactionsString = transactionEntry; // Initialize if empty
    }
    localStorage.setItem('transactions', transactionsString); // Save back to storage
}

// Retrieve all stored transactions

function getAllTransactions() {
    let transactionsString = localStorage.getItem('transactions') || ''; // Get stored transactions
    return transactionsString.split('|').filter(item => item.trim() !== '').map(transactionEntry => {
        let parts = transactionEntry.split(':');
        return {
            id: parts[0],
            category: parts[1],
            amount: parts[2],
            date: parts[3]
        }; // Convert to structured object
    });
}

// Save a budget setting
function saveBudget(budgetCategory, budgetAmount) {
    let budgetsString = localStorage.getItem('budgets') || ''; // Retrieve budgets
    let budgetsArray = budgetsString.split('|').filter(item => item.trim() !== ''); // Convert to array

    let categoryFound = false;
    budgetsArray = budgetsArray.map(budgetEntry => {
        let parts = budgetEntry.split(':'); // Split category and amount
        if (parts[0] === budgetCategory) {
            categoryFound = true; 
            return budgetCategory + ':' + budgetAmount; // Update budget amount
        }
        return budgetEntry; // Keep unchanged
    });
    if (!categoryFound) {
        budgetsArray.push(budgetCategory + ':' + budgetAmount); // Add new category if not found
    }
    localStorage.setItem('budgets', budgetsArray.join('|')); // Save updated budgets
}


// Retrieve all stored budgets

function getAllBudgets() {
    let budgetsString = localStorage.getItem('budgets') || ''; // Get stored budgets
    return budgetsString.split('|').filter(item => item.trim() !== '').map(budgetEntry => { // Convert to array
        let parts = budgetEntry.split(':');
        return {
            category: parts[0],
            amount: parts[1]
        }; // Convert to object
    });
}


// Delete an account by name

function deleteAccount(accountName) {
    let accountsString = localStorage.getItem('accounts') || '';
    let accountsArray = accountsString.split('|').filter(item => item.trim() !== '');

    accountsArray = accountsArray.filter(accountEntry => {
        let parts = accountEntry.split(':'); // Extract account name
        return parts[0] !== accountName; // Keep all(except the one)to delete
    });
    localStorage.setItem('accounts', accountsArray.join('|')); // Save updated list
}


// Delete a transaction by ID

function deleteTransaction(transactionId) {
    let transactionsString = localStorage.getItem('transactions') || '';
    let transactionsArray = transactionsString.split('|').filter(item => item.trim() !== '');

    transactionsArray = transactionsArray.filter(transactionEntry => {
        let parts = transactionEntry.split(':');
        return parts[0] !== String(transactionId); // Remove matching ID
    });
    localStorage.setItem('transactions', transactionsArray.join('|')); 
}


// Delete a budget by category

function deleteBudget(budgetCategory) {
    let budgetsString = localStorage.getItem('budgets') || '';
    let budgetsArray = budgetsString.split('|').filter(item => item.trim() !== '');

    budgetsArray = budgetsArray.filter(budgetEntry => {
        let parts = budgetEntry.split(':');
        return parts[0] !== budgetCategory; // Remove matching category
    });
    localStorage.setItem('budgets', budgetsArray.join('|'));
}


// Clear all stored data

function clearAllData() {
    localStorage.removeItem('accounts');
    localStorage.removeItem('transactions');
    localStorage.removeItem('budgets');
    location.reload()
}